int uname_get_os_info(struct os_info_type *os_info);
char *uname_get_host_name(char *hostname,char *domain);


