struct logo_info *load_logo_from_disk(char *filename);
